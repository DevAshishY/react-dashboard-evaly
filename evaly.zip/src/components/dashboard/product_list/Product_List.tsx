import React, { useState } from "react";
import { styled } from "styled-components";


export const InputStyle = styled.div`
  position: relative;

`;

const Product_List: React.FC = () => {
  return (
    <>
      <h2>THis Product_List</h2>
    </>
  );
};

export default Product_List;
