import React, { useState } from "react";
import { styled } from "styled-components";


export const InputStyle = styled.div`
  position: relative;

`;

const Brand: React.FC = () => {
  return (
    <>
      <h2>THis Brand</h2>
    </>
  );
};

export default Brand;
