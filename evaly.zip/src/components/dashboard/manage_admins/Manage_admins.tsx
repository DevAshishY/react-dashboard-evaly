import React, { useState } from "react";
import { styled } from "styled-components";


export const InputStyle = styled.div`
  position: relative;

`;

const Manage_admins: React.FC = () => {
  return (
    <>
      <h2>THis Manage_admins</h2>
    </>
  );
};

export default Manage_admins;
