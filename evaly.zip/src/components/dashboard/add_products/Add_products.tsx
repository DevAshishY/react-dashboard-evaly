import React, { useState } from "react";
import { styled } from "styled-components";


export const InputStyle = styled.div`
  position: relative;

`;

const Add_products: React.FC = () => {
  return (
    <>
      <h2>THis Add_products</h2>
    </>
  );
};

export default Add_products;
