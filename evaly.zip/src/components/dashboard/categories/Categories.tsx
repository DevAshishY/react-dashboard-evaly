import React, { useState } from "react";
import { styled } from "styled-components";


export const InputStyle = styled.div`
  position: relative;

`;

const Categories: React.FC = () => {
  return (
    <>
      <h2>THis Categories</h2>
    </>
  );
};

export default Categories;
