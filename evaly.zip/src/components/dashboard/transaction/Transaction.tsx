import React, { useState } from "react";
import { styled } from "styled-components";


export const InputStyle = styled.div`
  position: relative;

`;

const Transaction: React.FC = () => {
  return (
    <>
      <h2>THis Transaction</h2>
    </>
  );
};

export default Transaction;
