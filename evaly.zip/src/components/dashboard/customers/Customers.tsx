import React, { useState } from "react";
import { styled } from "styled-components";


export const InputStyle = styled.div`
  position: relative;

`;

const Customers: React.FC = () => {
  return (
    <>
      <h2>THis Customers</h2>
    </>
  );
};

export default Customers;
