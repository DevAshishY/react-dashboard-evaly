import React, { useState } from "react";
import { styled } from "styled-components";


export const InputStyle = styled.div`
  position: relative;

`;

const Admin_roles: React.FC = () => {
  return (
    <>
      <h2>THis Admin_roles</h2>
    </>
  );
};

export default Admin_roles;
