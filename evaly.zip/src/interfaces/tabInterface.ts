export default interface TabInterface {
	name: string;
}

