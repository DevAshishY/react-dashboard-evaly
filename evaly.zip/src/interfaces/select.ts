export default interface SelectElementProps {
	options: { name: string }[]; // Assuming options is an array of objects with a name property
  }